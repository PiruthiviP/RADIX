import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Building2, 
  MapPin, 
  Users, 
  GraduationCap,
  GitBranch,
  Lightbulb,
  TrendingUp,
  Target,
  Zap,
  Shield,
  Rocket,
  Code,
  Globe,
  Clock,
  Star,
  AlertTriangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { mockCompanyFull } from '@/data/mockCompanies';
import { cn } from '@/lib/utils';

const mockTrends = [
  {
    name: 'Generative AI at Enterprise Scale',
    description: 'Enterprises are moving from GenAI pilots to production-grade, governed deployments.',
    horizon: 3,
    importance: 'Critical',
    drivers: ['LLM maturity', 'Productivity pressure', 'Executive AI mandates'],
  },
  {
    name: 'Industry-Specific Digital Platforms',
    description: 'Clients demand verticalized solutions rather than generic digital transformations.',
    horizon: 4,
    importance: 'High',
    drivers: ['Complex regulation', 'Domain specialization'],
  },
  {
    name: 'Cloud-Native Modernization',
    description: 'Large enterprises are modernizing legacy estates using modular, API-first architectures.',
    horizon: 5,
    importance: 'Critical',
    drivers: ['Legacy risk', 'Cloud economics', 'Speed to market'],
  },
];

const mockCompetitors = [
  {
    name: 'IBM Consulting',
    type: 'Direct',
    strength: 'Hybrid cloud and enterprise AI',
    bet: 'Watsonx Consulting Stack',
    threat: 'High',
  },
  {
    name: 'Deloitte',
    type: 'Direct',
    strength: 'C-suite relationships and industry depth',
    bet: 'Industry Cloud Accelerators',
    threat: 'High',
  },
  {
    name: 'Capgemini',
    type: 'Direct',
    strength: 'Engineering and managed services',
    bet: 'AI-Augmented Delivery',
    threat: 'Medium',
  },
];

const mockProjects = [
  {
    tier: 'Tier 1',
    name: 'Enterprise GenAI Factory',
    problem: 'Clients cannot industrialize GenAI use cases quickly.',
    objective: 'Rapid GenAI deployment at scale',
    technologies: ['Python', 'FastAPI', 'React', 'LangChain', 'Azure OpenAI'],
    value: 'Faster AI ROI',
  },
  {
    tier: 'Tier 1',
    name: 'Industry Cloud Accelerators',
    problem: 'Industry transformations take too long.',
    objective: 'Speed up digital transformation',
    technologies: ['Java', 'Spring Boot', 'Angular', 'Kubernetes'],
    value: 'Higher transformation success',
  },
  {
    tier: 'Tier 2',
    name: 'Autonomous Managed Services',
    problem: 'Managed services are labor-intensive.',
    objective: 'AI-driven operations',
    technologies: ['Python', 'Kafka', 'AIOps', 'Process Mining'],
    value: 'Margin improvement',
  },
  {
    tier: 'Tier 3',
    name: 'Responsible AI Governance Suite',
    problem: 'AI programs lack governance.',
    objective: 'Ensure ethical AI usage',
    technologies: ['Java', 'Explainability tools', 'Compliance dashboards'],
    value: 'Reduced regulatory risk',
  },
];

const getTierColor = (tier: string) => {
  switch (tier) {
    case 'Tier 1':
      return 'bg-emerald/10 text-emerald border-emerald/30';
    case 'Tier 2':
      return 'bg-blue-500/10 text-blue-600 border-blue-500/30';
    case 'Tier 3':
      return 'bg-purple-500/10 text-purple-600 border-purple-500/30';
    default:
      return 'bg-muted text-muted-foreground';
  }
};

const CompanyInnovX = () => {
  const { companyId } = useParams();
  const navigate = useNavigate();
  const company = mockCompanyFull;

  const getCategoryBadgeClass = (category: string) => {
    switch (category.toLowerCase()) {
      case 'marquee': return 'badge-marquee';
      case 'superdream': return 'badge-super-dream';
      case 'dream': return 'badge-dream';
      case 'regular': return 'badge-regular';
      case 'enterprise': return 'badge-enterprise';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >
      {/* Sticky Header */}
      <div className="bg-card border border-border rounded-2xl p-6 shadow-card sticky top-0 z-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
              {company.logo_url ? (
                <img src={company.logo_url} alt={company.short_name} className="w-8 h-8 object-contain" />
              ) : (
                <Building2 className="w-6 h-6 text-muted-foreground" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display font-bold text-xl">{company.short_name}</h1>
                <span className={cn('px-2 py-0.5 text-xs rounded-full', getCategoryBadgeClass(company.category))}>
                  {company.category}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{company.headquarters_address}</span>
                <span className="flex items-center gap-1"><Users className="w-3 h-3" />{company.employee_size}</span>
              </div>
            </div>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2" onClick={() => navigate(`/companies/${companyId}/skills`)}>
              <GraduationCap className="w-4 h-4" />
              Skill Sets
            </Button>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => navigate(`/companies/${companyId}/process`)}>
              <GitBranch className="w-4 h-4" />
              Hiring Process
            </Button>
            <Button variant="default" size="sm" className="gap-2">
              <Lightbulb className="w-4 h-4" />
              INNOVX
            </Button>
          </div>
        </div>
      </div>

      {/* Hero */}
      <div className="relative overflow-hidden rounded-3xl gradient-primary p-8 text-primary-foreground">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary-foreground/10 rounded-full text-sm mb-4">
            <Rocket className="w-4 h-4" />
            Innovation Intelligence
          </div>
          <h2 className="font-display text-2xl font-bold mb-2">INNOVX Analysis</h2>
          <p className="text-primary-foreground/80 max-w-xl">
            Discover industry trends, competitive landscape, and strategic innovation projects.
            Align your skills with the future of {company.short_name}.
          </p>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary-foreground/5 rounded-full blur-3xl" />
      </div>

      {/* Industry Trends */}
      <section>
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-amber-500/10 rounded-lg">
            <TrendingUp className="w-5 h-5 text-amber-500" />
          </div>
          <h3 className="font-display text-xl font-bold">Industry Trends</h3>
        </div>
        
        <div className="grid md:grid-cols-3 gap-4">
          {mockTrends.map((trend, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-card border border-border rounded-2xl p-6"
            >
              <div className="flex items-start justify-between mb-3">
                <span className={cn(
                  'px-2 py-1 text-xs font-medium rounded-full',
                  trend.importance === 'Critical' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                )}>
                  {trend.importance}
                </span>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {trend.horizon}yr horizon
                </span>
              </div>
              <h4 className="font-semibold mb-2">{trend.name}</h4>
              <p className="text-sm text-muted-foreground mb-3">{trend.description}</p>
              <div className="flex flex-wrap gap-1">
                {trend.drivers.map((driver, i) => (
                  <span key={i} className="px-2 py-0.5 bg-secondary text-xs rounded-md">
                    {driver}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Competitive Landscape */}
      <section>
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-rose-500/10 rounded-lg">
            <Target className="w-5 h-5 text-rose-500" />
          </div>
          <h3 className="font-display text-xl font-bold">Competitive Landscape</h3>
        </div>
        
        <div className="grid md:grid-cols-3 gap-4">
          {mockCompetitors.map((comp, index) => (
            <div key={index} className="bg-card border border-border rounded-2xl p-6">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold">{comp.name}</h4>
                <span className={cn(
                  'px-2 py-0.5 text-xs font-medium rounded-full flex items-center gap-1',
                  comp.threat === 'High' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                )}>
                  <AlertTriangle className="w-3 h-3" />
                  {comp.threat}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{comp.strength}</p>
              <div className="mt-3 pt-3 border-t border-border">
                <p className="text-xs text-muted-foreground mb-1">Strategic Bet</p>
                <p className="text-sm font-medium">{comp.bet}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Student Innovation Projects */}
      <section>
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-accent/10 rounded-lg">
            <Zap className="w-5 h-5 text-accent" />
          </div>
          <h3 className="font-display text-xl font-bold">Student Innovation Projects</h3>
        </div>
        <p className="text-muted-foreground mb-6">
          Tiered project ideas to build skills aligned with {company.short_name}'s strategic focus
        </p>
        
        <div className="space-y-4">
          {['Tier 1', 'Tier 2', 'Tier 3'].map(tier => (
            <div key={tier}>
              <div className="flex items-center gap-2 mb-3">
                <Star className={cn(
                  'w-4 h-4',
                  tier === 'Tier 1' ? 'text-emerald' :
                  tier === 'Tier 2' ? 'text-blue-500' : 'text-purple-500'
                )} />
                <h4 className="font-semibold">
                  {tier} — {tier === 'Tier 1' ? 'Foundational' : tier === 'Tier 2' ? 'Advanced' : 'Breakthrough'}
                </h4>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                {mockProjects
                  .filter(p => p.tier === tier)
                  .map((project, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-card border border-border rounded-2xl p-6 hover:shadow-card-hover transition-all"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <h5 className="font-display font-semibold">{project.name}</h5>
                        <span className={cn(
                          'px-2 py-0.5 text-xs font-medium rounded-full border',
                          getTierColor(project.tier)
                        )}>
                          {project.tier}
                        </span>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-3">
                        <strong>Problem:</strong> {project.problem}
                      </p>
                      
                      <p className="text-sm mb-3">
                        <strong>Objective:</strong> {project.objective}
                      </p>
                      
                      <div className="flex flex-wrap gap-1 mb-3">
                        {project.technologies.slice(0, 4).map((tech, i) => (
                          <span key={i} className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-md">
                            {tech}
                          </span>
                        ))}
                      </div>
                      
                      <div className="pt-3 border-t border-border">
                        <p className="text-xs text-muted-foreground">Business Value</p>
                        <p className="text-sm font-medium text-accent">{project.value}</p>
                      </div>
                    </motion.div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default CompanyInnovX;
