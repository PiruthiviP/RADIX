import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Building2, 
  MapPin, 
  Users, 
  GraduationCap,
  GitBranch,
  Lightbulb,
  CheckCircle2,
  Clock,
  Monitor,
  Users2,
  Brain,
  Code,
  MessageSquare,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { mockCompanyFull } from '@/data/mockCompanies';
import { cn } from '@/lib/utils';

const mockRounds = [
  {
    round_number: 1,
    round_name: 'Online Assessment',
    round_category: 'Coding Test',
    evaluation_type: 'Technical',
    assessment_mode: 'Online',
    duration: '90 minutes',
    skill_sets: [
      {
        skill_name: 'Data Structures & Algorithms',
        typical_questions: [
          'Find maximum sum subarray',
          'Detect cycle in an undirected graph',
          'Find the first non-repeating character',
        ],
      },
      {
        skill_name: 'Coding',
        typical_questions: [
          'Implement inventory reconciliation logic',
          'Write code to merge sorted arrays',
          'Optimize a function for large input size',
        ],
      },
      {
        skill_name: 'Aptitude',
        typical_questions: [
          'Data interpretation on sales metrics',
          'Logical reasoning with constraints',
          'Basic probability question',
        ],
      },
    ],
  },
  {
    round_number: 2,
    round_name: 'Technical Interview Round 1',
    round_category: 'Interview',
    evaluation_type: 'Technical',
    assessment_mode: 'Online',
    duration: '60 minutes',
    skill_sets: [
      {
        skill_name: 'Data Structures',
        typical_questions: [
          'Explain hash table collisions',
          'Solve a binary tree traversal problem',
          'Time complexity analysis of sorting algorithms',
        ],
      },
      {
        skill_name: 'Operating Systems',
        typical_questions: [
          'Explain multithreading',
          'Difference between process and thread',
          'Basics of memory management',
        ],
      },
      {
        skill_name: 'SQL',
        typical_questions: [
          'Query to find top-selling products by category',
          'Difference between INNER and OUTER JOIN',
          'Indexing basics',
        ],
      },
    ],
  },
  {
    round_number: 3,
    round_name: 'System Design Interview',
    round_category: 'Interview',
    evaluation_type: 'Technical',
    assessment_mode: 'Online',
    duration: '45 minutes',
    skill_sets: [
      {
        skill_name: 'System Design',
        typical_questions: [
          'Design an online order management system',
          'Design a recommendation system at high level',
          'How would you scale checkout services',
        ],
      },
      {
        skill_name: 'Object-Oriented Design',
        typical_questions: [
          'Design an object-oriented shopping cart',
          'Apply design patterns for extensibility',
          'Explain SOLID principles',
        ],
      },
    ],
  },
  {
    round_number: 4,
    round_name: 'Managerial & HR Round',
    round_category: 'Interview',
    evaluation_type: 'HR',
    assessment_mode: 'Online',
    duration: '30 minutes',
    skill_sets: [
      {
        skill_name: 'Communication',
        typical_questions: [
          'Describe a challenging project',
          'How do you handle conflicting priorities',
          'Why this company?',
        ],
      },
    ],
  },
];

const getRoundIcon = (category: string) => {
  switch (category.toLowerCase()) {
    case 'coding test':
      return Code;
    case 'interview':
      return Users2;
    case 'hackathon':
      return Brain;
    default:
      return MessageSquare;
  }
};

const getRoundColor = (type: string) => {
  switch (type.toLowerCase()) {
    case 'technical':
      return 'bg-blue-500';
    case 'hr':
      return 'bg-green-500';
    default:
      return 'bg-amber-500';
  }
};

const CompanyProcess = () => {
  const { companyId } = useParams();
  const navigate = useNavigate();
  const company = mockCompanyFull;

  const getCategoryBadgeClass = (category: string) => {
    switch (category.toLowerCase()) {
      case 'marquee': return 'badge-marquee';
      case 'superdream': return 'badge-super-dream';
      case 'dream': return 'badge-dream';
      case 'regular': return 'badge-regular';
      case 'enterprise': return 'badge-enterprise';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Sticky Header */}
      <div className="bg-card border border-border rounded-2xl p-6 shadow-card sticky top-0 z-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
              {company.logo_url ? (
                <img src={company.logo_url} alt={company.short_name} className="w-8 h-8 object-contain" />
              ) : (
                <Building2 className="w-6 h-6 text-muted-foreground" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display font-bold text-xl">{company.short_name}</h1>
                <span className={cn('px-2 py-0.5 text-xs rounded-full', getCategoryBadgeClass(company.category))}>
                  {company.category}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{company.headquarters_address}</span>
                <span className="flex items-center gap-1"><Users className="w-3 h-3" />{company.employee_size}</span>
              </div>
            </div>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2" onClick={() => navigate(`/companies/${companyId}/skills`)}>
              <GraduationCap className="w-4 h-4" />
              Skill Sets
            </Button>
            <Button variant="default" size="sm" className="gap-2">
              <GitBranch className="w-4 h-4" />
              Hiring Process
            </Button>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => navigate(`/companies/${companyId}/innovx`)}>
              <Lightbulb className="w-4 h-4" />
              INNOVX
            </Button>
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div>
        <h2 className="font-display text-2xl font-bold mb-2">Hiring Process</h2>
        <p className="text-muted-foreground">
          End-to-end hiring process timeline with detailed round information
        </p>
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border" />

        <div className="space-y-6">
          {mockRounds.map((round, index) => {
            const Icon = getRoundIcon(round.round_category);
            const lineColor = getRoundColor(round.evaluation_type);
            
            return (
              <motion.div
                key={round.round_number}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-20"
              >
                {/* Timeline node */}
                <div className={cn(
                  'absolute left-4 w-8 h-8 rounded-full flex items-center justify-center z-10',
                  lineColor,
                  'text-white'
                )}>
                  <Icon className="w-4 h-4" />
                </div>

                {/* Card */}
                <div className="bg-card border border-border rounded-2xl p-6 shadow-card">
                  {/* Round Header */}
                  <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <span className="text-sm font-medium text-muted-foreground">
                          Round {round.round_number}
                        </span>
                        <span className={cn(
                          'px-2 py-0.5 text-xs font-medium rounded-full',
                          round.evaluation_type === 'Technical' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                        )}>
                          {round.evaluation_type}
                        </span>
                      </div>
                      <h3 className="font-display font-bold text-lg">{round.round_name}</h3>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Monitor className="w-4 h-4" />
                        {round.assessment_mode}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {round.duration}
                      </span>
                    </div>
                  </div>

                  {/* Skill Sets */}
                  <div className="space-y-4">
                    {round.skill_sets.map((skill, skillIndex) => (
                      <div key={skillIndex} className="bg-secondary/30 rounded-xl p-4">
                        <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                          <Brain className="w-4 h-4 text-primary" />
                          {skill.skill_name}
                        </h4>
                        <div className="space-y-2">
                          {skill.typical_questions.map((question, qIndex) => (
                            <div key={qIndex} className="flex items-start gap-2 text-sm">
                              <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">{question}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
};

export default CompanyProcess;
