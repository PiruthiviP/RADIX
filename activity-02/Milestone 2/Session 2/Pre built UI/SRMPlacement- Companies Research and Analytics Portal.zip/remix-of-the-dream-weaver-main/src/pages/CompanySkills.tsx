import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Building2, 
  MapPin, 
  Users, 
  Calendar,
  GraduationCap,
  GitBranch,
  Lightbulb,
  Brain,
  Code,
  MessageSquare,
  Database,
  Cloud,
  Settings,
  Cpu,
  Network,
  Monitor,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { mockCompanyFull, getCompanyById } from '@/data/mockCompanies';
import { cn } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const skillSets = [
  { code: 'COD', name: 'Coding', icon: Code, color: 'text-blue-500' },
  { code: 'DSA', name: 'Data Structures & Algorithms', icon: Brain, color: 'text-purple-500' },
  { code: 'APTI', name: 'Aptitude & Problem Solving', icon: Brain, color: 'text-amber-500' },
  { code: 'COMM', name: 'Communication Skills', icon: MessageSquare, color: 'text-green-500' },
  { code: 'OOD', name: 'Object-Oriented Design', icon: Settings, color: 'text-indigo-500' },
  { code: 'AI', name: 'AI Native Engineering', icon: Cpu, color: 'text-pink-500' },
  { code: 'SQL', name: 'SQL & Database Design', icon: Database, color: 'text-cyan-500' },
  { code: 'SYSD', name: 'System Design', icon: Network, color: 'text-orange-500' },
  { code: 'DEVOPS', name: 'DevOps & Cloud', icon: Cloud, color: 'text-sky-500' },
  { code: 'SWE', name: 'Software Engineering', icon: Settings, color: 'text-slate-500' },
  { code: 'NET', name: 'Computer Networking', icon: Network, color: 'text-teal-500' },
  { code: 'OS', name: 'Operating Systems', icon: Monitor, color: 'text-rose-500' },
];

const levels = Array.from({ length: 10 }, (_, i) => i + 1);

// Mock topics per skill per level
const mockTopics: Record<string, Record<number, string[]>> = {
  'COD': {
    1: ['Basic syntax', 'Variables', 'Loops'],
    2: ['Functions', 'Arrays', 'Strings'],
    3: ['Recursion', 'Pointers', 'Memory'],
    4: ['OOP basics', 'Classes', 'Objects'],
    5: ['Error handling', 'File I/O', 'Debugging'],
    6: ['Advanced OOP', 'Design patterns intro', 'Testing'],
    7: ['Concurrency basics', 'Threading', 'Async'],
    8: ['Performance optimization', 'Profiling', 'Benchmarking'],
    9: ['System programming', 'Low-level optimization'],
    10: ['Compiler design', 'Language internals', 'VM design'],
  },
  'DSA': {
    1: ['Arrays', 'Basic searching', 'Sorting basics'],
    2: ['Linked lists', 'Stacks', 'Queues'],
    3: ['Trees', 'Binary trees', 'Tree traversal'],
    4: ['Hash tables', 'Sets', 'Maps'],
    5: ['Heaps', 'Priority queues', 'BST'],
    6: ['Graphs', 'BFS', 'DFS'],
    7: ['Dynamic programming', 'Memoization'],
    8: ['Advanced graphs', 'Shortest path', 'MST'],
    9: ['String algorithms', 'Trie', 'Suffix arrays'],
    10: ['Advanced DP', 'Segment trees', 'Fenwick trees'],
  },
};

const CompanySkills = () => {
  const { companyId } = useParams();
  const navigate = useNavigate();
  const company = mockCompanyFull;

  const getCategoryBadgeClass = (category: string) => {
    switch (category.toLowerCase()) {
      case 'marquee': return 'badge-marquee';
      case 'superdream': return 'badge-super-dream';
      case 'dream': return 'badge-dream';
      case 'regular': return 'badge-regular';
      case 'enterprise': return 'badge-enterprise';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Sticky Header */}
      <div className="bg-card border border-border rounded-2xl p-6 shadow-card sticky top-0 z-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
              {company.logo_url ? (
                <img src={company.logo_url} alt={company.short_name} className="w-8 h-8 object-contain" />
              ) : (
                <Building2 className="w-6 h-6 text-muted-foreground" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display font-bold text-xl">{company.short_name}</h1>
                <span className={cn('px-2 py-0.5 text-xs rounded-full', getCategoryBadgeClass(company.category))}>
                  {company.category}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{company.headquarters_address}</span>
                <span className="flex items-center gap-1"><Users className="w-3 h-3" />{company.employee_size}</span>
              </div>
            </div>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex gap-2">
            <Button variant="default" size="sm" className="gap-2">
              <GraduationCap className="w-4 h-4" />
              Skill Sets
            </Button>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => navigate(`/companies/${companyId}/process`)}>
              <GitBranch className="w-4 h-4" />
              Hiring Process
            </Button>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => navigate(`/companies/${companyId}/innovx`)}>
              <Lightbulb className="w-4 h-4" />
              INNOVX
            </Button>
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div>
        <h2 className="font-display text-2xl font-bold mb-2">Hiring Skill Sets</h2>
        <p className="text-muted-foreground">
          Comprehensive skill matrix showing topic expectations at each level
        </p>
      </div>

      {/* Skills Grid */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full min-w-[1200px]">
            <thead>
              <tr className="bg-secondary/50">
                <th className="px-4 py-4 text-left font-medium text-muted-foreground sticky left-0 bg-secondary/50 z-10 w-48">
                  Skill Set
                </th>
                {levels.map(level => (
                  <th key={level} className="px-3 py-4 text-center font-medium text-muted-foreground min-w-[120px]">
                    <div className={cn(
                      'inline-flex items-center justify-center w-8 h-8 rounded-lg text-sm',
                      level <= 3 ? 'bg-green-100 text-green-700' :
                      level <= 6 ? 'bg-amber-100 text-amber-700' :
                      level <= 8 ? 'bg-orange-100 text-orange-700' :
                      'bg-red-100 text-red-700'
                    )}>
                      L{level}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {skillSets.map((skill, skillIndex) => {
                const Icon = skill.icon;
                return (
                  <tr key={skill.code} className={cn(skillIndex % 2 === 0 ? 'bg-card' : 'bg-secondary/20')}>
                    <td className="px-4 py-4 sticky left-0 bg-inherit z-10">
                      <div className="flex items-center gap-3">
                        <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center bg-muted', skill.color)}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">{skill.name}</p>
                          <p className="text-xs text-muted-foreground">{skill.code}</p>
                        </div>
                      </div>
                    </td>
                    {levels.map(level => {
                      const topics = mockTopics[skill.code]?.[level] || ['Topic 1', 'Topic 2', 'Topic 3'];
                      return (
                        <td key={level} className="px-3 py-4">
                          <div className="flex flex-wrap gap-1">
                            {topics.slice(0, 3).map((topic, i) => (
                              <span 
                                key={i} 
                                className="px-2 py-0.5 bg-secondary text-secondary-foreground text-xs rounded-md"
                              >
                                {topic}
                              </span>
                            ))}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-6 text-sm">
        <span className="font-medium text-muted-foreground">Difficulty:</span>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-green-100" />
          <span className="text-muted-foreground">L1-L3 Beginner</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-amber-100" />
          <span className="text-muted-foreground">L4-L6 Intermediate</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-orange-100" />
          <span className="text-muted-foreground">L7-L8 Advanced</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-3 rounded bg-red-100" />
          <span className="text-muted-foreground">L9-L10 Expert</span>
        </div>
      </div>
    </motion.div>
  );
};

export default CompanySkills;
