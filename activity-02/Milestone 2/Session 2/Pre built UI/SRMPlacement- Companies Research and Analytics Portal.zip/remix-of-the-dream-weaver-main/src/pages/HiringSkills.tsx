import { motion } from 'framer-motion';
import { useState } from 'react';
import { GraduationCap, Filter, ChevronDown, Info } from 'lucide-react';
import { CompanySearch } from '@/components/search/CompanySearch';
import { mockCompaniesShort } from '@/data/mockCompanies';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const skillSets = [
  { code: 'COD', name: 'Coding', icon: '💻' },
  { code: 'DSA', name: 'Data Structures & Algorithms', icon: '🧮' },
  { code: 'APTI', name: 'Aptitude & Problem Solving', icon: '🧠' },
  { code: 'COMM', name: 'Communication Skills', icon: '💬' },
  { code: 'OOD', name: 'Object-Oriented Design', icon: '🏗️' },
  { code: 'AI', name: 'AI Native Engineering', icon: '🤖' },
  { code: 'SQL', name: 'SQL & Database Design', icon: '🗄️' },
  { code: 'SYSD', name: 'System Design', icon: '📐' },
  { code: 'DEVOPS', name: 'DevOps & Cloud', icon: '☁️' },
  { code: 'SWE', name: 'Software Engineering', icon: '⚙️' },
  { code: 'NET', name: 'Computer Networking', icon: '🌐' },
  { code: 'OS', name: 'Operating Systems', icon: '🖥️' },
];

const bloomLevels: Record<string, { name: string; color: string }> = {
  'RE': { name: 'Remember', color: 'bg-slate-200 text-slate-700' },
  'UN': { name: 'Understand', color: 'bg-blue-100 text-blue-700' },
  'AP': { name: 'Apply', color: 'bg-green-100 text-green-700' },
  'AN': { name: 'Analyze', color: 'bg-yellow-100 text-yellow-700' },
  'EV': { name: 'Evaluate', color: 'bg-orange-100 text-orange-700' },
  'CR': { name: 'Create', color: 'bg-red-100 text-red-700' },
};

// Mock data for skill ratings
const mockSkillRatings: Record<string, Record<string, { rating: number; bloom: string }>> = {
  'Google': {
    'COD': { rating: 9, bloom: 'EV' },
    'DSA': { rating: 10, bloom: 'CR' },
    'APTI': { rating: 7, bloom: 'AN' },
    'COMM': { rating: 6, bloom: 'AP' },
    'OOD': { rating: 8, bloom: 'EV' },
    'AI': { rating: 9, bloom: 'CR' },
    'SQL': { rating: 7, bloom: 'AN' },
    'SYSD': { rating: 9, bloom: 'CR' },
    'DEVOPS': { rating: 6, bloom: 'AP' },
    'SWE': { rating: 8, bloom: 'EV' },
    'NET': { rating: 5, bloom: 'UN' },
    'OS': { rating: 7, bloom: 'AN' },
  },
  'Microsoft': {
    'COD': { rating: 9, bloom: 'EV' },
    'DSA': { rating: 9, bloom: 'EV' },
    'APTI': { rating: 6, bloom: 'AP' },
    'COMM': { rating: 7, bloom: 'AN' },
    'OOD': { rating: 9, bloom: 'CR' },
    'AI': { rating: 8, bloom: 'EV' },
    'SQL': { rating: 8, bloom: 'EV' },
    'SYSD': { rating: 9, bloom: 'CR' },
    'DEVOPS': { rating: 8, bloom: 'EV' },
    'SWE': { rating: 9, bloom: 'CR' },
    'NET': { rating: 6, bloom: 'AP' },
    'OS': { rating: 8, bloom: 'EV' },
  },
  'Amazon': {
    'COD': { rating: 9, bloom: 'EV' },
    'DSA': { rating: 9, bloom: 'CR' },
    'APTI': { rating: 5, bloom: 'AP' },
    'COMM': { rating: 8, bloom: 'EV' },
    'OOD': { rating: 8, bloom: 'EV' },
    'AI': { rating: 7, bloom: 'AN' },
    'SQL': { rating: 7, bloom: 'AN' },
    'SYSD': { rating: 10, bloom: 'CR' },
    'DEVOPS': { rating: 7, bloom: 'AN' },
    'SWE': { rating: 8, bloom: 'EV' },
    'NET': { rating: 6, bloom: 'AP' },
    'OS': { rating: 7, bloom: 'AN' },
  },
  'TCS': {
    'COD': { rating: 6, bloom: 'AP' },
    'DSA': { rating: 6, bloom: 'AP' },
    'APTI': { rating: 8, bloom: 'EV' },
    'COMM': { rating: 7, bloom: 'AN' },
    'OOD': { rating: 5, bloom: 'UN' },
    'AI': { rating: 4, bloom: 'UN' },
    'SQL': { rating: 7, bloom: 'AN' },
    'SYSD': { rating: 5, bloom: 'UN' },
    'DEVOPS': { rating: 5, bloom: 'UN' },
    'SWE': { rating: 6, bloom: 'AP' },
    'NET': { rating: 6, bloom: 'AP' },
    'OS': { rating: 5, bloom: 'UN' },
  },
  'Infosys': {
    'COD': { rating: 6, bloom: 'AP' },
    'DSA': { rating: 6, bloom: 'AP' },
    'APTI': { rating: 7, bloom: 'AN' },
    'COMM': { rating: 7, bloom: 'AN' },
    'OOD': { rating: 5, bloom: 'AP' },
    'AI': { rating: 5, bloom: 'UN' },
    'SQL': { rating: 6, bloom: 'AP' },
    'SYSD': { rating: 5, bloom: 'UN' },
    'DEVOPS': { rating: 5, bloom: 'UN' },
    'SWE': { rating: 6, bloom: 'AP' },
    'NET': { rating: 5, bloom: 'UN' },
    'OS': { rating: 5, bloom: 'UN' },
  },
  'Accenture': {
    'COD': { rating: 5, bloom: 'AP' },
    'DSA': { rating: 5, bloom: 'AP' },
    'APTI': { rating: 7, bloom: 'AN' },
    'COMM': { rating: 8, bloom: 'EV' },
    'OOD': { rating: 5, bloom: 'AP' },
    'AI': { rating: 6, bloom: 'AP' },
    'SQL': { rating: 6, bloom: 'AP' },
    'SYSD': { rating: 5, bloom: 'UN' },
    'DEVOPS': { rating: 6, bloom: 'AP' },
    'SWE': { rating: 6, bloom: 'AP' },
    'NET': { rating: 5, bloom: 'UN' },
    'OS': { rating: 4, bloom: 'RE' },
  },
};

const HiringSkills = () => {
  const [selectedSkills, setSelectedSkills] = useState<string[]>(skillSets.map(s => s.code));

  const toggleSkill = (code: string) => {
    if (selectedSkills.includes(code)) {
      if (selectedSkills.length > 1) {
        setSelectedSkills(selectedSkills.filter(s => s !== code));
      }
    } else {
      setSelectedSkills([...selectedSkills, code]);
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 8) return 'text-emerald font-bold';
    if (rating >= 6) return 'text-amber-500 font-semibold';
    if (rating >= 4) return 'text-muted-foreground';
    return 'text-muted-foreground/50';
  };

  const companies = Object.keys(mockSkillRatings);

  return (
    <TooltipProvider>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="space-y-6"
      >
        {/* Page Header */}
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground mb-2">
            Hiring Skill Sets
          </h1>
          <p className="text-muted-foreground">
            Compare skill expectations and cognitive depth across recruiters
          </p>
        </div>

        {/* Search */}
        <CompanySearch 
          companies={mockCompaniesShort} 
          placeholder="Search company to view detailed skills..."
        />

        {/* Skill Set Selector */}
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-muted-foreground" />
              <h3 className="font-medium">Filter Skill Sets</h3>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setSelectedSkills(skillSets.map(s => s.code))}
                className="text-sm text-primary hover:underline"
              >
                Select All
              </button>
              <span className="text-muted-foreground">|</span>
              <button 
                onClick={() => setSelectedSkills(['COD', 'DSA'])}
                className="text-sm text-primary hover:underline"
              >
                Reset
              </button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {skillSets.map(skill => (
              <button
                key={skill.code}
                onClick={() => toggleSkill(skill.code)}
                className={cn(
                  'px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center gap-2',
                  selectedSkills.includes(skill.code)
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                )}
              >
                <span>{skill.icon}</span>
                {skill.name}
              </button>
            ))}
          </div>
        </div>

        {/* Bloom's Taxonomy Legend */}
        <div className="flex flex-wrap items-center gap-3 text-sm">
          <span className="font-medium text-muted-foreground">Bloom's Levels:</span>
          {Object.entries(bloomLevels).map(([code, { name, color }]) => (
            <span key={code} className={cn('px-2 py-0.5 rounded text-xs', color)}>
              {code} = {name}
            </span>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-secondary/50">
                <tr>
                  <th className="px-6 py-4 text-left font-medium text-muted-foreground sticky left-0 bg-secondary/50 z-10">
                    Company
                  </th>
                  {skillSets
                    .filter(s => selectedSkills.includes(s.code))
                    .map(skill => (
                      <th key={skill.code} className="px-4 py-4 text-center font-medium text-muted-foreground min-w-[100px]">
                        <Tooltip>
                          <TooltipTrigger className="cursor-help">
                            <div className="flex flex-col items-center gap-1">
                              <span className="text-lg">{skill.icon}</span>
                              <span className="text-xs">{skill.code}</span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{skill.name}</p>
                          </TooltipContent>
                        </Tooltip>
                      </th>
                    ))}
                </tr>
              </thead>
              <tbody>
                {companies.map((company, index) => (
                  <tr key={company} className={cn(index % 2 === 0 ? 'bg-card' : 'bg-secondary/20')}>
                    <td className="px-6 py-4 font-medium sticky left-0 bg-inherit z-10">
                      {company}
                    </td>
                    {skillSets
                      .filter(s => selectedSkills.includes(s.code))
                      .map(skill => {
                        const data = mockSkillRatings[company]?.[skill.code];
                        if (!data) return <td key={skill.code} className="px-4 py-4 text-center text-muted-foreground">-</td>;
                        
                        return (
                          <td key={skill.code} className="px-4 py-4 text-center">
                            <Tooltip>
                              <TooltipTrigger>
                                <div className="flex flex-col items-center gap-1">
                                  <span className={cn('text-xl', getRatingColor(data.rating))}>
                                    {data.rating}
                                  </span>
                                  <span className={cn(
                                    'px-1.5 py-0.5 rounded text-xs',
                                    bloomLevels[data.bloom]?.color || 'bg-muted'
                                  )}>
                                    {data.bloom}
                                  </span>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Rating: {data.rating}/10</p>
                                <p>Level: {bloomLevels[data.bloom]?.name}</p>
                              </TooltipContent>
                            </Tooltip>
                          </td>
                        );
                      })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Info */}
        <div className="flex items-start gap-3 p-4 bg-primary/5 border border-primary/10 rounded-xl">
          <Info className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <div className="text-sm text-muted-foreground">
            <p className="font-medium text-foreground mb-1">How to read this table</p>
            <p>Each cell shows the Rating (1-10) and Bloom's Taxonomy level. Higher ratings indicate stronger expectations. Click on any company to view their detailed skill matrix with topic breakdowns.</p>
          </div>
        </div>
      </motion.div>
    </TooltipProvider>
  );
};

export default HiringSkills;
